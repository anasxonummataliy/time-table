from typing import Optional
from pydantic import BaseModel, Field, ConfigDict


class RoomBase(BaseModel):
    number: str = Field(..., min_length=1, max_length=20, examples=["301-A"])
    capacity: Optional[int] = Field(None, ge=1, le=1000, examples=[60])
    room_type: Optional[str] = Field(None, max_length=50, examples=["Darsxona"])
    floor: Optional[int] = Field(None, ge=1, le=30, examples=[3])


class RoomCreate(RoomBase):
    pass


class RoomUpdate(BaseModel):
    number: Optional[str] = Field(None, min_length=1, max_length=20)
    capacity: Optional[int] = Field(None, ge=1, le=1000)
    room_type: Optional[str] = Field(None, max_length=50)
    floor: Optional[int] = Field(None, ge=1, le=30)


class RoomResponse(RoomBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
